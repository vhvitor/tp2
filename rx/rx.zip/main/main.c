#include <stdio.h>
#include <stdlib.h>
#include "../include/eventmanager.h"

int main(){
    em_run_simulation();

    return 0;
}
