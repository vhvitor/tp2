#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "../include/arrivalsimulation.h"
#include "../include/patient.h"

#define ARRIVAL_PROBABILITY 0.2

// Structure for arrival simulation
// Estrutura para a simulação de chegada
struct arrival_simulation {
    int num_patients_treated;
    GenericQueue *patient_queue;
    Patient *patient;
};

// Signatures of private functions
// Assinaturas das funções privadas
static int _as_patient_arrived();
static void _as_process_arrival(ArrivalSimulation *as, int current_time);



// Public functions // Funções públicas


ArrivalSimulation *as_create() {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */

    // Allocates memory for a arrival simulation structure
    // Aloca memória para uma estrutura de simulação de chegada
    ArrivalSimulation *as = (ArrivalSimulation *) malloc(sizeof(ArrivalSimulation));

    // Checks if the allocation successful
    // Verifica se a alocação foi bem sucedida
    if (!as) {
        fprintf(stderr, "Error: arrival simulation allocation failure/n");
        return NULL;
    }

    // Builds the patient's queue
    // Constrói a fila de pacientes
    as->patient_queue = gq_create();

    // Checks success in creating the queue
    // Verifica o sucesso na criação da fila
    if (!as->patient_queue) {
        fprintf(stderr, "Error: queue creation failure \n");
        return NULL;
    }

    // Builds the patient's object
    // Constrói o objeto paciente
    as->patient = patient_create();

    // Checks success in creating the patient object
    // Verifica o sucesso na criação do objeto paciente
    if (!as->patient) {
        fprintf(stderr, "Error: patient object creation failure \n");
        return NULL;
    }

    return as;
}

void as_destroyer(ArrivalSimulation *as) {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */


    if (as) {
        gq_destroyer(&(as->patient_queue));
        patient_destroyer(as->patient);
        free(as);
    }
}



void as_patient_arrival_callback(void *context, int current_time) {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */


    // Casting for Arrival Simulation type
    ArrivalSimulation *as = (ArrivalSimulation *) context;

    if (_as_patient_arrived()) {
        _as_process_arrival(as, current_time);
        as->num_patients_treated++;
    } else return;
}

void as_run(Dispatcher *dispatcher, ArrivalSimulation *as, int current_time) {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */


    // Registers the event in the dispatcher
    // Registra o evento no disparador
    disp_register_callback(dispatcher, EVENT_PATIENT_ARRIVAL, as_patient_arrival_callback);

    // Trigger the dispatcher
    // Aciona o disparador
    disp_trigger_event(dispatcher, EVENT_PATIENT_ARRIVAL, as, current_time);
}


// GETTERS

const GenericQueue *as_get_patient_queue(ArrivalSimulation *as){
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */

    return as->patient_queue;
}

const int as_get_num_patients_treated(ArrivalSimulation *as) {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */


    return as->num_patients_treated;
}



// Private Functions // Funções privadas


const int _as_patient_arrived() {
    return ((rand() / (double) RAND_MAX) < ARRIVAL_PROBABILITY);
}

const void _as_process_arrival(ArrivalSimulation *as, int current_time) {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */


    // Generates a patient's id
    // Gera um id de paciente
    const int patient_id = patient_generation_id(as->patient_queue);

    // Sets the patient's id
    // Define o id do paciente
    patient_set_id(as->patient, patient_id);

    // Generates a random patient' name
    // Gera um nome de paciente aleatório
    const char *patient_name = patient_generation_random_name();

    // Sets the patient's name
    // Define o nome do paciente
    patient_set_name(as->patient, patient_name);

    // Sets the patient's timestamp
    // Define o timestamp do paciente
    patient_set_timestamp(as->patient, current_time);

    // Format the patient object to string
    // Formata o objeto paciente para string
    const char *formatted_patient = patient_format_to_string(as->patient);

    // Saves the patient to the database
    // Salva o paciente no banco de dados
    patient_save(as->patient, "db_patient.txt", formatted_patient);

    // Insert the patient at the end of the queue
    // Insere o paciente no final da fila
    gq_enqueue(as->patient_queue, (void *) as->patient);
}
