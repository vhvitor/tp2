#include <stdio.h>

#include "../include/exampriorityqueue.h"
#include "../include/genericqueue.h"
#include "../include/exam.h"




struct exam_priority_queue {
    GenericQueue priority_queues[6];
    Exam *exam;
};


// OPERATIONS // OPERAÇÕES

ExamPriorityQueue *epq_create() {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */


    // Allocates memory for an exam priority queue structure
    // Aloca memória para uma estrutura fila de prioridades de exames
    ExamPriorityQueue *epq = (ExamPriorityQueue *) calloc(1, sizeof(ExamPriorityQueue));

    // Checks if the allocation successfull
    // Verifica se a alocação foi bem sucedida
    if (!epq) {
        fprintf(stderr, "Error: exam priority queue allocation failure\n");
        return NULL;
    }

    // Initializes the priority queues
    // Starta as filas de prioridades
    for (int i = 0; i < 6; i++) {
        epq->priority_queues[i] = gq_create();

        if (!epq->priority_queues[i]) {
            fprintf(stderr, "Error: priority queue %d allocation failure\n", i);

            // If the creation fails, destroys the previously created queues
            // Se a criação falhar, destrói as filas criadas anteriormente
            for (int j = 0; j < i; j++) {
                gq_destroyer(epq->priority_queues[j]);
            }

            free(epq);
            return NULL;
        }
    }

    // Builds the Exam
    // Constrói o Exam
    epq->exam = exam_create();

    // If the build fails, destroy the queues
    // Se a construção falhar, destrói as filas
    if (!epq->exam) {
        for (int i = 0; i < 6; i++) {
            gq_destroyer(epq->priority_queues[i]);
        }

        // Destroys the exam
        // Destrói o exame
        epq_destroyer(epq);
    }


    return epq;
}

void epq_destroyer(ExamPriorityQueue *epq) {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */


    if (!epq) {
        fprintf(stderr, "Exam priority queue is null\n");
        return;
    }

    // Destroys the priority queues
    // Destrói as filas de prioridades
    for (int i = 0; i < 6; i++) {
        gq_destroyer(epq->priority_queues[i]);
    }

    // Destroys the exam
    // Destrói o exame
    exam_destroyer(epq->exam);

    // Free memory of the exam priority queue
    // Libera memória para a fila de prioridades de exames
    free(epq);
}

int epq_is_empty(const ExamPriorityQueue *epq, PriorityType type) {
    /** \brief
     *
     * \param
     * \param
     * \return
     *
     */


    if (epq == NULL) {
        fprintf(stderr, "Error: ExamPriorityQueue pointer is NULL.\n");
        return 0; // Or handle the error as appropriate
    }

    // Validate type if there's a range for PriorityType
    // Validar tipo se houver um intervalo para PriorityType
    if (type < 0 || type >= NUMBER_OF_PRIORITY_TYPES) {
        fprintf(stderr, "Error: Invalid PriorityType value.\n");
        return 0;
    }

    return gq_is_empty(epq->priority_queues[type]);
}
